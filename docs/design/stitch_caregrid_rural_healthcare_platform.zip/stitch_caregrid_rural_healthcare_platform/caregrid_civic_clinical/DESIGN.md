---
name: CareGrid Civic Clinical
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#3e4948'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#6e7979'
  outline-variant: '#bec9c8'
  surface-tint: '#016a6a'
  primary: '#005454'
  on-primary: '#ffffff'
  primary-container: '#0d6e6e'
  on-primary-container: '#9dedec'
  inverse-primary: '#84d4d3'
  secondary: '#006d41'
  on-secondary: '#ffffff'
  secondary-container: '#91f4b8'
  on-secondary-container: '#007144'
  tertiary: '#743c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#975000'
  on-tertiary-container: '#ffd8bb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f0f0'
  primary-fixed-dim: '#84d4d3'
  on-primary-fixed: '#002020'
  on-primary-fixed-variant: '#004f50'
  secondary-fixed: '#94f7bb'
  secondary-fixed-dim: '#78daa0'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#005230'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-md-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an authoritative, ultra-reliable digital public infrastructure aesthetic for rural public health administration and ground-level healthcare delivery. Designed to support ASHA workers, Auxiliary Nurse Midwives (ANMs), Primary Health Centre (PHC) medical officers, and district administrative leads across rural Maharashtra, the interface prioritizes clarity, non-fatiguing legibility under harsh outdoor sunlight, and unmistakable operational trust.

The visual direction draws from modern civic engineering and Indian Digital Public Goods (such as ABHA, CoWIN, and Ayushman Bharat platforms), avoiding trendy consumer gimmicks, frosted glass, or ornamental neon accents. Its character is rooted in **Institutional Modernism**: crisp planar structures, deliberate structural contrast, utilitarian density management, and clear semantic signifiers. Every screen must project the stability and accountability of an official governmental lifeline while remaining compassionate, frictionless, and accessible to field operators with varying digital fluency.

## Colors

The color palette is engineered for unequivocal legibility, high color distinction under field conditions, and strict conformance to WCAG 2.1 AAA contrast targets for foundational workflows.

### Palette Roles
- **Primary (`#0D6E6E`)**: Deep Clinical Teal. Establishes institutional gravity, administrative trust, and calm clinical rigor. Used for core application navigation, key interactive states, structural banners, and principal call-to-action buttons.
- **Secondary (`#1B8755`)**: Warm Emerald Green. Used exclusively for affirmative, validated states: offline-synced indicators, verified ABHA identity badges, completed immunizations, and active clinical supply batches.
- **Tertiary (`#D97706`)**: Indian Deep Saffron / Warm Amber. Signifies observational urgency, pending PHC verification, incomplete field surveys, and conditional triage alerts requiring field visit follow-up.
- **Critical Alert (`#DC2626`)**: Muted Crimson. Strictly isolated for clinical escalations, emergency maternal alerts, high-risk vitals requiring immediate medical officer intervention, and sync failures.
- **Neutral (`#475569`)**: Balanced Slate Gray. Powers structural borders, secondary body content, sub-headers, and muted iconography.

### Surfaces and Canvas
The interface operates in a persistent high-legibility light theme. Base page backgrounds use `#F8FAFC` (Slate Tint) to mitigate ocular glare in outdoor field settings. Cards and operational modules reside on `#FFFFFF` (Pure Hospital White), framed with explicit `#CBD5E1` clinical borders to preserve visual segmentation on low-tier IPS screens.

## Typography

The typographic hierarchy is built on **Inter**, paired seamlessly with system-fallback Noto Sans Devanagari for regional language localization across Marathi (मराठी) and Hindi (हिंदी).

### System Principles
- **Optical Density & Contrast**: Large x-heights and open apertures guarantee unhindered reading of patient identification records, medication dosages, and vital ranges on scratch-damaged or low-resolution smartphone displays.
- **Multilingual Vertical Metrics**: All line-height parameters accommodate Devanagari vowel signs (matras) and conjunct consonants without vertical clipping or awkward row overlap. When switching between English, Marathi, or Hindi, parent container heights remain fixed.
- **Numerical Regularity**: Tabular figures (`tnum`) must be enforced on all metric grids, demographic tallies, ABHA IDs, and blood pressure readings to maintain columnar alignment across dashboard lists.

## Layout & Spacing

The system enforces an 8pt-based, content-prioritized responsive grid constructed to handle asymmetric field devices—from entry-level 5.5-inch handhelds to dual-monitor desktop setups at District Collectorates.

### Breakpoints and Canvas Behavior
- **Mobile (320px – 599px)**: 4-column fluid layout with `margin: 1rem` (16px) and `gutter: 1rem` (16px). Bottom-anchored primary touch panels and sticky utility bars prioritize thumb-zone reachability during standing field checkups.
- **Tablet (600px – 1023px)**: 8-column layout with `margin: 1.5rem` (24px). Split-pane triage workflows display the village household list alongside patient health files.
- **Desktop / Clinical Workstation (1024px+)**: 12-column layout with max-width constrained to `1280px` for form entries or fluid spanning across full screens for district epidemiological monitoring.

### Ergonomic Directives
All touch targets must satisfy an uncompromising minimum dimension of **48px x 48px**, surrounded by at least `space-sm` (8px) of isolation to prevent mistaps during rapid field data recording.

## Elevation & Depth

Visual hierarchy relies on crisp surface layering and firm architectural borders rather than diffuse, CPU-heavy blur effects or deep drop shadows. This preserves render performance on hardware-constrained field tablets and avoids low-contrast ambiguity under intense outdoor daylight.

### Layering Hierarchy
- **Level 0 (App Canvas)**: `#F8FAFC`. Structural baseline.
- **Level 1 (Clinical Cards & Data Blocks)**: `#FFFFFF`. Bounded by a continuous 1px solid border in `#CBD5E1`. Used for patient record cards, inventory lists, and metric summaries.
- **Level 2 (Active Modals, Drawers & Triage Panels)**: `#FFFFFF` floating above an opaque, 40% `#0F172A` scrim. Elevated with an ambient micro-shadow: `0 4px 12px -2px rgba(15, 23, 42, 0.08), 0 2px 6px -1px rgba(15, 23, 42, 0.04)`.
- **Level 3 (System Sticky Bars & Sync Notifications)**: Fixed-position banners placed at top or bottom boundaries, using solid high-contrast backgrounds (`#085656` or `#0F172A`) with zero blur for immediate operational legibility.

## Shapes

The interface adopts a disciplined **Soft (`1`)** shape language, applying `0.25rem` (4px) radii to micro-elements and `0.5rem` (8px) radii to major operational cards and input fields. 

This restrained curvature balances contemporary visual hygiene with a structured, civic demeanor. Pill shapes (`9999px`) are strictly reserved for functional state indicators—such as triage tags, live network connectivity chips, and language selectors—guaranteeing that actionable cards and data containers retain clear, rectangular spatial definition.

## Components

### Buttons
- **Primary Button**: Solid `#0D6E6E` fill, `#FFFFFF` text, `border-radius: 0.25rem`. Height: `48px`. Hover state: `#085656`. Focus: 2px solid `#0D6E6E` offset by 2px.
- **Secondary Button**: 1.5px solid `#0D6E6E` border, transparent background, `#0D6E6E` text. Height: `48px`.
- **Destructive/Escalation Button**: Solid `#DC2626` fill, `#FFFFFF` text. Used exclusively for red-flag maternal/neonatal triage referrals.

### Cards & Household Tiles
Cards feature `#FFFFFF` backgrounds, `0.5rem` radius, and a 1px solid `#CBD5E1` border. When tagged with an active clinical triage status, cards display an unmistakable 4px vertical accent stripe along their left boundary:
- **Normal/Routine**: `#1B8755`
- **Follow-up Needed**: `#D97706`
- **Critical / Doctor Referral**: `#DC2626`

### Multilingual Language Switcher
Positioned permanently in the global utility header. Uses a segmented pill controller displaying native scripts: **English | मराठी | हिंदी**. The active selection uses `#0D6E6E` fill with `#FFFFFF` text; inactive segments display `#475569` with transparent backgrounds.

### Network Bandwidth & Offline Sync Banners
A persistent 36px high top status banner indicates data state across three non-diagnostic operational conditions:
- **Online (Synced)**: Minimal `#F0FDF4` background, `#1B8755` text, displaying a solid sync icon and timestamp of the last cloud handshake.
- **Low-Bandwidth / Pending Queue**: `#FEF3C7` background, `#92400E` text, detailing queued field records (e.g., "7 records saved locally — will auto-sync on network detection").
- **Offline Working Mode**: `#F1F5F9` background, `#334155` text, indicating full offline persistence with zero functional lockout.

### Input Fields & Controls
Text entries and numerical vitals fields feature a minimum height of `48px`, a 1.5px border in `#94A3B8`, and generous `1rem` horizontal padding. On focus, borders transition to 2px solid `#0D6E6E`. Field labels sit permanently above inputs at `14px` (`body-md-bold`) to ensure context is never lost when fields contain values. Checkboxes and radio buttons feature a minimum interaction surface of `24px` with high-contrast active check markers.

### Assistive Triage Badges
Status chips must include explicit textual labels alongside distinct shapes to aid colorblind operators. They must be clearly designated as decision-support indicators rather than autonomous diagnostic verdicts:
- Routine Care: Rounded pill, `#ECFDF5` background, `#065F46` label with circle glyph.
- Observation Pending: Square-rounded badge, `#FFFBEB` background, `#92400E` label with triangle glyph.
- Medical Officer Escalation: Square-rounded badge, `#FEF2F2` background, `#991B1B` label with octagon glyph.